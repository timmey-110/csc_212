#pragma once
#include <vector>

void mergesort(std::vector<int> &v);
