#pragma once
#include <vector>

void customsort(std::vector<int> &v);
