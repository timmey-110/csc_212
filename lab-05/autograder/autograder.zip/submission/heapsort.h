#pragma once
#include <vector>

void heapsort(std::vector<int> &vec);
