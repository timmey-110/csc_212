#pragma once
#include <cstdint>
#include <vector>

[[nodiscard]] size_t find_max_distance(const std::vector<int> &v);
